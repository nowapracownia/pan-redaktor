<?php

    if(!is_admin()) {
        $panRedaktor = new panRedaktor();
        $panRedaktor->panRedaktorInit();
    }

?>
